interface PaymentStrategy {
    boolean pay(double amount);
}
