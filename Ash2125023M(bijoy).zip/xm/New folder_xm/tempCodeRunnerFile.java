  // paymentSystem.setPaymentStrategy(new CreditCardPayment());
        // paymentSystem.makePayment(5500);