
interface Text {
    String getText();
    String getDescription();
}
